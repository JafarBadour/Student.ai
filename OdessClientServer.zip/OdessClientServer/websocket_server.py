import asyncio
import websockets
import json
from time import sleep
import datetime

connected = set()
p2s_index = {}
s2p_index = {}
opponent_index = {}
games_hist = {}


def transform(timeinstance):
    return timeinstance.seconds + timeinstance.microseconds /(1e6)


def calculate_time(game_hist, my_id, total_time):
    moves = game_hist['moves'].copy()
    turns = game_hist['turns'].copy()
    timestamps = game_hist['timestamps'].copy()
    opponent_id = opponent_index[my_id]
    total_time = int(total_time)
    my_time = datetime.timedelta(seconds=total_time * 60)
    if len(moves) == 0:
        return transform(my_time)
    opponent_time = datetime.timedelta(seconds=total_time * 60)
    turns.append(my_id if turns[-1] != my_id else opponent_id)
    timestamps.append(datetime.datetime.utcnow())
    for i in range(1, len(moves)+1):
        player = turns[i]
        timestamp_diff = (timestamps[i] - timestamps[i - 1])
        if player == my_id:
            my_time -= timestamp_diff
        else:
            opponent_time -= timestamp_diff

    return transform(my_time)


def get_key(id1, id2):
    return max(id1, id2) + ':' + min(id1, id2)


async def send_message(ws, message):
    try:
        await ws.send(json.dumps(message))
    except Exception as e:
        print(*e)
        my_id = s2p_index[ws]
        opponent_id = opponent_index[my_id]
        opponent_socket = p2s_index[opponent_id]
        print(opponent_socket.connected, ws.connected)
        connected.remove(ws)


def make_response(game_hist, my_id, opponent_id):
    my_time = calculate_time(game_hist, my_id, game_hist['gameTime'])
    opponent_time = calculate_time(game_hist, opponent_id, game_hist['gameTime'])
    if my_time <= 0:
        game_hist['result'] = {'winner': opponent_id}
    elif opponent_time <= 0:
        game_hist['result'] = {'winner': my_id}
    return {
        'response_type': 'state',
        'board_state': game_hist['board_state'][-1],
        'my_time': my_time,
        'opponent_time': opponent_time,
        'winner': game_hist['result']
    }


async def ping_handler(game_key, my_id, opponent_id, request):
    if not game_key in games_hist:
        games_hist[game_key] = {"ERROR": "ERROR"}
    my_client = p2s_index[my_id]
    opponent_client = p2s_index[opponent_id]
    resp = make_response(games_hist[game_key], my_id, opponent_id)
    await send_message(my_client, resp)
    await send_message(opponent_client, resp)


async def move_handler(game_key, my_id, opponent_id, request):
    if not game_key in games_hist:
        games_hist[game_key] = {"ERROR": "ERROR"}
    my_client = p2s_index[my_id]
    opponent_client = p2s_index[opponent_id]

    game_hist = games_hist[game_key]
    game_hist['moves'].append(request['transition'])
    game_hist['timestamps'].append(datetime.datetime.utcnow())
    game_hist['turns'].append(my_id)

    resp = {
        'response_type': 'move',
        'newpanel': request['newpanel'],
        'transition': request['transition']
    }

    await send_message(opponent_client, resp)


async def handle_message(client, message):
    request = json.loads(message)
    requests = [('ping', ping_handler), ('move', move_handler)]
    opponent_id = request['opponent_id']
    my_id = s2p_index[client]
    game_key = get_key(my_id, opponent_id)
    for rt, f2c in requests:
        if rt == request['request_type']:
            await f2c(game_key, my_id, opponent_id, request)


async def server(websocket, path):
    # Registeration
    if not websocket in s2p_index:
        info = await websocket.recv()

        info = json.loads(info)
        if info['request_type'] != 'register':
            await send_message(websocket, 'Err didnt register')
            return
        p2s_index[info['my_id']] = websocket
        s2p_index[websocket] = info['my_id']
        my_id = info['my_id']
        opponent_id = info['opponent_id']

        opponent_index[my_id] = opponent_id
        opponent_index[opponent_id] = my_id

        game_type = info['gameType']
        game_time = info['gameTime']
        mycolor = info['gameColor']

        game_key = get_key(my_id, opponent_id)
        games_hist[game_key] = {
            'board_state': ['testing_state'],
            'moves': [],
            'result': 'None',
            'color': {
                my_id: mycolor,
                opponent_id: 'W' if mycolor == 'B' else 'B'

            },
            'gameType': game_type,
            'gameTime': game_time,
            'turns': [],
            'timestamps': []
        }
        connected.add(websocket)
        print(websocket, my_id)
    # handle events
    try:
        print("Connections")
        for con in connected:
            print(s2p_index[con], ',')

        async for message in websocket:
            print(message)
            await handle_message(websocket, message)
    finally:
        # Unregister.
        connected.remove(websocket)


if __name__ == '__main__':
    start_server = websockets.serve(server, "localhost", 5000)

    asyncio.get_event_loop().run_until_complete(start_server)
    asyncio.get_event_loop().run_forever()
